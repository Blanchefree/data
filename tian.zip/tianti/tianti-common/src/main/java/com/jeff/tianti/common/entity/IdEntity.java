package com.jeff.tianti.common.entity;

import javax.persistence.MappedSuperclass;

/**
 * 统一定义实体的ID抽象类
 * @author Jeff Xu
 * @since 2015-12-09
 */
@MappedSuperclass
public class IdEntity {

}
