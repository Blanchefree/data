﻿jc.data.setup(function (data) {
    var html = '';

    html += '<div class="bs-example" data-example-id="thumbnails-with-custom-content margin-top-xl">';
    html += '<div class="row">';
    html += '<div class="col-sm-6 col-md-3">';
    html += '<div class="thumbnail">';
    html += '<img alt="100%x200" src="../../static/cache/4.jpg" data-holder-rendered="true">';
    html += '<div class="caption">';
    html += '<h4>Thumbnail label</h4>';
    html += '<p>Cras justo odio</p>';
    html += '<p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '<div class="col-sm-6 col-md-3">';
    html += '<div class="thumbnail">';
    html += '<img alt="100%x200" src="../../static/cache/5.jpg" data-holder-rendered="true">';
    html += '<div class="caption">';
    html += '<h4>Thumbnail label</h4>';
    html += '<p>Cras justo odio</p>';
    html += '<p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '<div class="col-sm-6 col-md-3">';
    html += '<div class="thumbnail">';
    html += '<img alt="100%x200" src="../../static/cache/6.jpg" data-holder-rendered="true">';
    html += '<div class="caption">';
    html += '<h4>Thumbnail label</h4>';
    html += '<p>Cras justo odio</p>';
    html += '<p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '<div class="col-sm-6 col-md-3">';
    html += '<div class="thumbnail">';
    html += '<img alt="100%x200" src="../../static/cache/7.jpg" data-holder-rendered="true">';
    html += '<div class="caption">';
    html += '<h4>Thumbnail label</h4>';
    html += '<p>Cras justo odio</p>';
    html += '<p><a href="#" class="btn btn-primary" role="button">Button</a> <a href="#" class="btn btn-default" role="button">Button</a></p>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '</div>';
    html += '</div>';



    return html;

});