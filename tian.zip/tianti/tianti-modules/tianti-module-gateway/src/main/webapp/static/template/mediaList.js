﻿jc.data.setup(function (data) {
    var html = '';

    html += '<div class="m_list">';
    html += '<ul class="media-list">';
    html += '<li class="media">';
    html += '<a class="pull-left" href="#">';
    html += '<img class="media-object" src="../../static/tmp/1.jpg">';
    html += '</a>';
    html += '<div class="media-body">';
    html += '<h4 class="media-heading">如何看待未来</h4>';
    html += '<p>我们应有恒心，尤其要有自信心。未来　在我们的手中，我们要做最精彩的一代。<p>';
    html += '</div>';
    html += '</li>';
    html += '<li class="media">';
    html += '<a class="pull-left" href="#">';
    html += '<img class="media-object" src="../../static/tmp/2.jpg">';
    html += '</a>';
    html += '<div class="media-body">';
    html += '<h4 class="media-heading">成长的岁月是什么</h4>';
    html += '<p>成长的岁月，失去的已太多，让我们一起来珍惜拥有的一切。<p>';
    html += '</div>';
    html += '</li>';
    html += '<li class="media">';
    html += '<a class="pull-left" href="#">';
    html += '<img class="media-object" src="../../static/tmp/3.jpg">';
    html += '</a>';
    html += '<div class="media-body">';
    html += '<h4 class="media-heading">知识是什么</h4>';
    html += '<p>知识好比浩浩荡荡、奔流不息的江河，它是由无数涓涓小流汇成的，它有源头，却没有终点。<p>';
    html += '</div>';
    html += '</li>';
    html += '</ul>';
    html += '</div>';


    return html;

});